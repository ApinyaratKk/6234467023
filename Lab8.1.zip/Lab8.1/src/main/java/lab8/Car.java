package lab8;

public class Car {
    private int gas;
    private int efficiency;
    public Car(int gas,int efficiency){
        this.gas = gas;
        this.efficiency = efficiency;
    }
    public void drive(double distance){
        if (distance/efficiency > gas) {
            System.out.println("You cannot drive too far, please add gas");
        }
        else{
            gas -= distance/efficiency;
        }  
    }
    public void setGas(int amount){
        amount = gas;
    }
    public double getGas(){
        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
    public void addGas(double amount){
        gas += amount;
    }
}
