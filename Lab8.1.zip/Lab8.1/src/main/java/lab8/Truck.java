package lab8;

public class Truck extends Car {
    private int M_weight;
    private int weight;
    
    public Truck(int gas,int efficiency,int M_weight,int weight){
    super(gas,efficiency);
    this.M_weight = M_weight;
    if (weight > M_weight){
        this.weight = M_weight;
    }
    }
    public void drive(double distance){
        if (getGas() > (distance/getEfficiency())){
            if (weight > 20){
                super.setGas((int) (getGas()-(distance/getEfficiency())*1.3));
            }
            else if (weight >= 11){
                super.setGas((int) (getGas()-(distance/getEfficiency())*1.2));
            }
            else if (weight >= 1){
                super.setGas((int) (getGas()-(distance/getEfficiency())*1.1));
            }
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    }

}
