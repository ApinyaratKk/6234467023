package lab4_3;

public class TimeInterval {
    public double start_h,start_m,end_h,end_m,hour,minute ;
    
    public void Time(double Start,double End){
        start_h = Start/100; //choose 2 num front 
        start_m = Start%100; //choose 2 numback 
        end_h = End/100; //choose 2 numfront
        end_m = End%100; //2 numback
    }
    
    public double getHours(){
        hour = end_h - start_h ;
        return (int) hour;
    }
    public double getMinutes(){
        minute = end_m - start_m ;
        return (int) minute;
    }
    
}
