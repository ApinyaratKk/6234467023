package lab3_1;

public class InsectPopulation {

        public double insect;
    
        public InsectPopulation (double num){
            insect = num ;
        }
    
        public void breed() {
            insect = 2*insect ;
        }
    
        public void spray(){
            insect = insect-(insect*0.1) ;
        }
    
        public double getNumInsect() {
            return insect;
        }
}

    

