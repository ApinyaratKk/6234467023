package lab3_1;

public class InsectPopulationTester {
    public static void main(String[] args){
        InsectPopulation num = new InsectPopulation(10);
        num.breed();
        num.spray();
        System.out.println("Number of insects :" + num.getNumInsect());
        num.breed();
        num.spray();
        System.out.println("Number of insects :" + num.getNumInsect());
        num.breed();
        num.spray();
        System.out.println("Number of insects :" + num.getNumInsect());
    }
    
}
