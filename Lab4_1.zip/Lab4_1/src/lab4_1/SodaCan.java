package lab4_1;
import java.lang.Math;

public class SodaCan {
    public float height;
    public float diameter;
    public double volume;
    public double surfaceArea;
    
    public SodaCan(int height,int diameter) {
        this.height = height;
        this.diameter = diameter;
}
    
    public void Volume() {
        volume = Math.PI*Math.pow((diameter/2),2)*height;
    }
    
    public void Surfacearea(){
        surfaceArea = 2*Math.PI*(diameter/2)*(height+(diameter/2));
    }
    
    public double getVolume() {
        return volume ;
    }
    
    public double getSurfaceArea() {
        return surfaceArea ;
    }
}
