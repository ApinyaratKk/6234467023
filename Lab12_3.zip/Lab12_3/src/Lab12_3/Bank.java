package Lab12_3;

public class Bank {
    
    public static void main(String[] args) {
        
        FileMatch test = new FileMatch();
        test.addTransObject();
        test.addAccountObject();
        test.updateinfo();
        System.out.println("Total Account : "+test.accoutCnt());
        System.out.println("Total balance : "+test.updateBalance());
        System.out.println("No transaction : "+test.noTrans()+" account.");
    }
}
