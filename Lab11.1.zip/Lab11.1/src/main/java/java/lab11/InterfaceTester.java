package java.lab11;

public class InterfaceTester {
    
    public static void main(String[] args) {
        
        MusicBox music = new MusicBox();
        music.enqueue("ออเจ้าเอย");
        music.enqueue("เธอหนอเธอ");
        music.enqueue("เพียงสบตา");
        music.enqueue("บุพเพสันนิวาส");
        music.dequeue();
        music.dequeue();
        music.dequeue();
        music.dequeue();
        
        SelfCheckOut self = new SelfCheckOut(); 
        self.enqueue(new Product("Pen", 25)); 
        self.enqueue(new Product("Pencil", 10)); 
        self.enqueue(new Product("Ruler", 20));
        self.enqueue(new Product("Eraser", 15));
        self.enqueue(new Product("Pencil Box", 30));
        self.dequeue();
        self.dequeue();
        self.dequeue();
        self.dequeue();
        self.dequeue();
        System.out.println("Total amount = " + self.getAmount()); 
 
    }
    
}

