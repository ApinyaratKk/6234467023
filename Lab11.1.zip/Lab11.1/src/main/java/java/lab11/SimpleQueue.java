package java.lab11;

public interface SimpleQueue {
    void enqueue(Object o);
           void dequeue();
}
