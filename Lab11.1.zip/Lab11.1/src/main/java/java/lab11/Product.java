package java.lab11;

public class Product {
    String goods;
    double amount;
     
    public Product(String goods, int i) {
        this.goods = goods;
        amount = i;
        
    }
    public String getGoods(){
        return goods;
    }
    public double getAmount(){
        return amount;
    }
 
}

