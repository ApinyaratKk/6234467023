/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab2_2 ;
/**
 *
 * @author user
 */
public class HollePrintor {
    
    public static void main(String args[]){  
        String word = "Hello, World!";  
        String replace ;
        replace = word.replace("o","x").replace("e","o").replace("x","e") ;
        System.out.println(replace);
    }
}
