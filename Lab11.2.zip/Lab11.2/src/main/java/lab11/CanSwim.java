package lab11;

public interface CanSwim {
    void swim(Terrain terrain);
    
}
