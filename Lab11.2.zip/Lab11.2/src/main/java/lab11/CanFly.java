package lab11;

public interface CanFly {
    void fly(Terrain terrain);
}

