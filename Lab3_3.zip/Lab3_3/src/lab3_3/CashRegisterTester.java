package lab3_3;

public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister test = new CashRegister();
        test.getTax(7);
        test.recordPurchase(50);
        test.recordPurchase(10);
        test.recordTaxPurchase(20);
        test.setPayment(100);
        test.getTotalTax();
        test.giveChange();
    }
    
}
