package Lab10;

public interface Evaluation {
    double evaluate();
    char grade(double evaluate);
    
}