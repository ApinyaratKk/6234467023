package lab3_2;

public class LetterPrinter {
    public static void main(String[] args){
        Letter jade = new Letter("Jade","Clarissa");
        jade.addLine("We must find Simon quikly.\nHe might be in danger.");
        System.out.print(jade.getText());
    }
}
