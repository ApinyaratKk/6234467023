package lab3_2;

public class Letter {
    private String from;
    private String to;
    private String line = " ";
    public Letter(String from,String to){
        this.from = from;
        this.to = to;
    }
    public void addLine(String line) {
        this.line = this.line + "\n"+line;
        
    }
    public String getText(){
        String text = "Dear " +from+":"+"\n"+this.line+"\n\n"+"Sincerely,"+"\n\n"+to+"\n\n";
        return text;
    }
}
