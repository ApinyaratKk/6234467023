/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab2_3 ;

import java.util.Calendar ; 
/**
 *
 * @author user
 */
public class GregorianCalendar {
    
    public static void main(String[] args) {
        java.util.GregorianCalendar cal = new java.util.GregorianCalendar() ;
        cal.add(Calendar.DAY_OF_MONTH, 100) ;
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH) ;
        int year = cal.get(Calendar.YEAR) ;
        int month = cal.get(Calendar.MONTH) ;
        int weekday = cal.get(Calendar.DAY_OF_WEEK) ;
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year) ;
        
        java.util.GregorianCalendar myBirthday = new java.util.GregorianCalendar(2000,Calendar.DECEMBER,25) ;
        myBirthday.add(Calendar.DAY_OF_MONTH,10000) ;
        int myDayOfMonth = myBirthday.get(Calendar.DAY_OF_MONTH) ;
        int myYear = myBirthday.get(Calendar.YEAR) ;
        int myMonth = myBirthday.get(Calendar.MONTH) ;
        int myWeekday = myBirthday.get(Calendar.DAY_OF_WEEK) ;
        System.out.println(myWeekday+" "+myDayOfMonth+" "+myMonth+" "+myYear) ;
    }
}
