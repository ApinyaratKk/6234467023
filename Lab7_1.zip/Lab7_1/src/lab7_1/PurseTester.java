package lab7_1;

import java.util.Scanner;
import java.util.ArrayList;

public class PurseTester {
    public static void main(String[] args){
        Purse walletA = new Purse();
        Purse walletB = new Purse();
        ArrayList<String> coinA = new ArrayList<String>();
        ArrayList<String> coinB = new ArrayList<String>();
        String getCoin;
        String getCoin2;
        Scanner typing = new Scanner(System.in);
        System.out.print("Enter coin type in wallet 1(Penny,Nickle,Dime,Half,Quarter): ");
            getCoin = typing.nextLine();
        if (!"Stop".equals(getCoin)){
            do{
                if(!"Quarter".equals(getCoin) && !"Dime".equals(getCoin) && !"Half".equals(getCoin) && !"Nickle".equals(getCoin) && !"Penny".equals(getCoin) && !"Stop".equals(getCoin)){
                    System.out.print("Enter coin type in wallet 1(Penny,Nickle,Dime,Half,Quarter): ");
                    getCoin = typing.nextLine();
                }
                else if (getCoin != "Stop"){
                    walletA.coinType(getCoin);
                    System.out.print("Enter coin type in wallet 1(Penny,Nickle,Dime,Half,Quarter) or enter Stop to stop: ");
                    getCoin = typing.nextLine();
                    
                }
            }
            while(!"Stop".equals(getCoin));
            System.out.print("Wallet 1: ");
            walletA.toString();
            coinA = walletA.reverse();
        }
        System.out.print("Enter coin type in wallet 2(Penny,Nickle,Dime,Half,Quarter): ");
        getCoin2 = typing.nextLine();
        if(!"Stop".equals(getCoin2)){
            do{
                if(!"Quarter".equals(getCoin2) && !"Dime".equals(getCoin2) && !"Half".equals(getCoin2) && !"Nickle".equals(getCoin2) && !"Penny".equals(getCoin2) && !"Stop".equals(getCoin2)){
                    System.out.print("Enter coin type in wallet 2(Penny,Nickle,Dime,Half,Quarter): ");
                    getCoin2 = typing.nextLine();
                }
                else if (getCoin2 != "Stop"){
                    walletB.coinType(getCoin2);
                    System.out.print("Enter coin type in wallet 2(Penny,Nickle,Dime,Half,Quarter) or enter Stop to stop: ");
                    getCoin2 = typing.nextLine();
                }
            }
            while(!"Stop".equals(getCoin2));
            System.out.print("Wallet 2: ");
            walletB.toString();
            coinB = walletB.reverse();
        }
        ArrayList<String> coinA2 = (ArrayList<String>)coinA.clone();
        ArrayList<String> coinB2 = (ArrayList<String>)coinB.clone();
        walletB.transfer(coinB,coinA);
        System.out.println("Same contents: "+walletA.sameContents(coinB2,coinA2));
        System.out.println("Same coins: "+walletA.sameCoins(coinB2,coinA2));

    }
}
