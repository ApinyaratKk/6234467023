package lab5_2;

import java.awt.geom.Point2D;
import static java.lang.Double.NaN;

public class Line {
    private double x,y,x1,x2,y1,y2,m,b;
    private boolean verticalline = false;
        
    public Line(double n1,double n2,double n3){
        x1 = n1;
        y1 = n2;
        m = n3;
        b = y1 - (m * x1);
    }
    
    public Line(double n1,double m1,double n2,double m2){
        x1 = n1;
        y1 = n1;
        x2 = n2;
        y2 = m2;
        m = (y2 - y1) / (x2 - x1);
        b = y1 - (m * x1);
    }
    
    public Line(double n1,double n2){
        m = n1;
        b = n2;
    }
    
    public Line(double n1){
        verticalline = true;
        x = n1 ;
        m = Double.NaN;
        b = Double.NaN;
    }
    
    public boolean equals(Line line){
        boolean equal = false;
        if (m == line.m && b == line.b){
            equal = true;
        }
        return equal;
    }
    
    public boolean isParallel(Line line){
        boolean parallel = false;
        if (m == line.m){
            parallel = true;
        }
        return parallel;
    }
    
    public boolean isIntersect(Line line){
        boolean intersect = false;
        if (m != line.m){
            intersect = true;
        }
        return intersect;
    }
    
    public Point2D.Double getIntersectionpoint(Line line){
        if (verticalline) {
            m = line.m;
            b = line.b;
            y = m * x + b;
        }
        else if (line.verticalline) {
            x = line.x;
            y = m * x + b;
        }
        else {
            x = (line.b-b)/(m-line.m);
            y = m * x + b;
        }
        
        Point2D point = new Point2D.Double(x,y);
        return (Point2D.Double) point;
    }   
}
