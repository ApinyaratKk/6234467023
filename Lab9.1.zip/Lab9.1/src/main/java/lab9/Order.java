package lab9;
import java.util.ArrayList;

public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    public void addPizza(Pizza p){
        this.p.add(p);
    }
    public String getOrderDetail(){
        String detail;
        this.id=cntOrder;
        String num=String.valueOf(id);
        detail="Order id : "+num+"\n"; //1
        detail+=c.getName()+" tel : "+c.getTel()+"\n"; //2
        for(int i=0; i<p.size();i++){
            detail+=p.get(i).getMenu()+" price : "+String.valueOf(p.get(i).getPrice())+p.get(i).getSpecial()+"\n"; //menu
        }
        detail+="Total pieces : "+String.valueOf(p.size())+"\n"; //3
        detail+="Total cost : "; //4
        double price = 0;
        for(int i=0;i<p.size();i++ ){
            price+=Double.valueOf(p.get(i).getPrice())-Double.valueOf(p.get(i).getPrice())*c.getDiscount()/100;
        }
        detail+=String.valueOf(price);
        return detail;
    }
    public double calculatePayment(){
        double price = 0;
        for(int i=0;i<p.size();i++ ){
            price+=Double.valueOf(p.get(i).getPrice())-Double.valueOf(p.get(i).getPrice())*c.getDiscount()/100;
        }
        return price;
    }
    public Order(Customer c){
        this.c=c;
        cntOrder+=1;
    }
    public String toString(){
        String user = "";
        for (Object a : p){
        user+=a;
        }
        return user;
    }
}