package lab5_1;

public class Zeller {
    private final int dayOfMonth ;
    private int month ;
    private int year ;
    public int h;
    public enum Day {SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),
        THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        public final String day;
        Day(String day){
            this.day = day;
        }
    
    }

    public Zeller (int day,int month,int year) {
        dayOfMonth = day ;
        this.month = month;
        this.year = year;
    
    }
    
    public Day getDayOfWeek() {
        if (month < 3) {
            month = month + 12 ;
            year = year - 1 ;
       
        }
        int q = dayOfMonth;
        int m = month;
        int j = year/100;
        int k = year%100;
        h = (q + (26 * (m + 1)) / 10 + k + (k / 4) + (j / 4) + (5 * j)) % 7;
        Day hDay = null ;
        switch (h) {
            case 0 : hDay = Day.SATURDAY; break;
            case 1 : hDay = Day.SUNDAY; break;
            case 2 : hDay = Day.MONDAY; break;
            case 3 : hDay = Day.TUESDAY; break;
            case 4 : hDay = Day.WEDNESDAY; break;
            case 5 : hDay = Day.THURSDAY; break;
            case 6 : hDay = Day.FRIDAY; break;
        }
        return hDay ;
        
    }
    
    
}
