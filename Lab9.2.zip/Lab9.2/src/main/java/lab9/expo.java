package lab9;

public class expo extends Taylor{
    
    public expo(int k,double x){
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public void printValue() {
        double sum=0;
        for(int n=0;n<=super.getIter();n++){
            sum+=(Math.pow(super.getValue(), n))/super.factorial(n);
        }
        System.out.println("Value from Math.exp() is "+getApprox()+".");
        System.out.println("Approximated value is "+sum+".");
    }

    @Override
    public double getApprox() {
        return Math.exp(super.getValue());
    }
    
}

