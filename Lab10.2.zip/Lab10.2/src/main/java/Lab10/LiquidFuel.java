package Lab10;

public interface LiquidFuel {
    double getRange();
    int getEmission();
}
