package lab6_1;

public class CannonBall {
    private double initV;
    private double simS;
    private double simT;
    public CannonBall(double initV){}
    public static final double g = 9.81;
    
    public void simulatedFlight() {
        int i = 1;
        while (initV >= 0) {
            initV-=g*0.01;
            simS+=initV*0.01;
            simT+=0.01;
            if (i%100 == 0){
                System.out.print("Distance on " + i/100 );
                System.out.printf(" sec : %.3f", simS);
                System.out.println();
            } 
        i++;
        }
    }
    public double calculusFlight(double t){
        simS = -0.5*g*simT*simT*initV*simT;
        return simS;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}



