package lab4_2;

public class DigitExtractor {
    private int num,n1;
    
    public DigitExtractor(int num){
        this.num = num;
    }
    public int nextDigit(){
        n1 = num%10;
        num = num/10;
        return n1;
    }
}

